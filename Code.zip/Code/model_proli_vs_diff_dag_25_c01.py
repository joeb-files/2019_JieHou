#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 20 10:25:02 2019

@author: houjie
"""



import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from datetime import datetime
from tensorflow.keras import regularizers
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense, Dropout, LSTM, BatchNormalization, Conv1D
from tensorflow.keras.callbacks import TensorBoard
from tensorflow.keras.callbacks import ModelCheckpoint
import time

tf.keras.backend.clear_session()
fil_diff = pd.read_excel('c01-Li_Astro_1517_relative_Impedanzspektren_d20.xlsx', skiprows = 0)
fil_proli = pd.read_excel('c01-Li_NPM_1519_relative_Impedanzspektren_d20.xlsx', skiprows = 0)

data_diff= np.asarray(fil_diff)
data_proli = np.asarray(fil_proli)

def remove_large_values(array):
    """
    Removes first column (frequency), and removez
    sequences with too large values (unphysical).
    """
    dummy_arr = []
    for i in range(1, len(array[:, 0])):
        too_large = False
        for j in range(0,len(array[0, :])):
            if array[i, j] > 600:
                too_large = True
        if not too_large:
            dummy_arr.append(array[i, :])
    return np.asarray(dummy_arr)


for i in range(1,len(data_diff[0,:])):

    plt.semilogx(data_diff[0,:]/1000, data_diff[i, :],'b', label='differentiation')
    plt.semilogx(data_proli[0,:]/1000, data_proli[i, :], 'g', label='proliferation')
plt.legend(['IMR90c01 1517 Differentiation', 'IMR90c01 1519 Proliferation'])
#plt.title("Compare proliferation and differetiation all measurements day 20")
plt.xlabel("Frequency [kHz]")
plt.ylabel("Relative impedance [%]")
plt.savefig('c01_day20_log.png')
plt.show()


def add_dimension(arr):
    new_arr = []
    for i in range(len(arr[0,:])):
        new_arr.append([ arr[:,i] ])
    return np.asarray(new_arr)

def pick_frequency_interval(arr,step):
    new_arr = []
    for i in range(step,len(arr[0,:]),step):
        new_arr.append(arr[i,:])
    return np.asarray(new_arr)

data_diff = remove_large_values(data_diff)
data_proli = remove_large_values(data_proli)
data_diff = np.rot90(data_diff)
data_proli = np.rot90(data_proli)

#data = pick_frequency_interval(data,5)
#data_uten_celler = pick_frequency_interval(data_uten_celler,5)

data_diff = np.flip(data_diff,axis = 0)
data_proli = np.flip(data_proli,axis = 0)
svar = np.ones(len(data_diff[0,:]))
svar_proli = np.zeros(len(data_proli[0,:]))
data_diff_svar = np.vstack((data_diff, svar))
data_proli_svar = np.vstack((data_proli, svar_proli))
total_data = np.concatenate((data_diff_svar, data_proli_svar), axis =1)
total_data = add_dimension(total_data)
total_data = np.swapaxes(total_data,1,2)
np.random.shuffle(total_data)
split_index = int(len(total_data[:,0])*0.9)

training_data = total_data[:split_index,:-1]
test_data = total_data[split_index:,:-1]
training_answers = total_data[:split_index,-1].astype(dtype=int)
test_answers = total_data[split_index:,-1].astype(dtype=int)

from tensorflow.keras.utils import to_categorical
test_answers = to_categorical(test_answers)
training_answers = to_categorical(training_answers)

eta_vals = np.logspace(-5, 1, 7)
lam_vals = np.logspace(-5, 1, 7)
decay_vals = np.logspace(-6,-2,7)
node_vals = np.linspace(10,17,8)
deca= 1e-06 #1e-5
eta = 0.000001
lam = 0.0001

NAME = "model_c01_Li_d20" #+ str(time.time())
EPOCHS=100
rnn_units = 24
def neuralNetwork(lam, eta, deca):

    regz = tf.keras.regularizers.l2(lam)#l1_l2(l1=0.01, l2=0.01)
   
    model = Sequential()
    model.add(LSTM(rnn_units, input_shape=training_data.shape[1:], return_sequences=True)) #, kernel_regularizer=regz,recurrent_regularizer=regz
    model.add(Dropout(0.4))
    model.add(BatchNormalization())
    model.add(LSTM(rnn_units*2, kernel_regularizer=regz,recurrent_regularizer=regz))# kernel_regularizer=regz,recurrent_regularizer=regz
    model.add(Dropout(0.4))
    model.add(BatchNormalization())
    model.add(Dense(2, activation='softmax')) #len(filenames)

    #Model compile settings:
    opt = tf.keras.optimizers.Adam(lr=eta, decay=deca)
    # Compile model
    model.compile(
        loss='categorical_crossentropy',
        optimizer=opt,
        metrics=['accuracy']
    )

    tensorboard = TensorBoard(log_dir="logs\{}.log".format(NAME))


    #checkpoint = ModelCheckpoint("X:models/{}.model".format(test, monitor='val_acc', verbose=1, save_best_only=True, mode='max')) # saves only the best ones
    #Train the model:
      # how many passes through our data
    BATCH_SIZE = 5
    history = model.fit(
        training_data, training_answers,
        shuffle=True,
        batch_size=BATCH_SIZE,
        epochs=EPOCHS,
        validation_data=(test_data, test_answers),
        callbacks=[tensorboard],
        #verbose=0,
    )
    plt.figure(1)
    plt.plot(history.history['acc'])
    plt.plot(history.history['val_acc'])
    plt.title('model accuracy')
    plt.ylabel('accuracy')
    plt.xlabel('epoch')
    plt.legend(['train', 'test'], loc='upper left')
    plt.show()
    # summarize history for loss
    plt.figure(2)
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['train', 'test'], loc='upper left')
    plt.show()

    score = model.evaluate(test_data, test_answers, verbose=0)
    print('Test loss:', score[0])
    print('Test accuracy:', score[1])
    # Save model
    model.save("model_c01_Li_d20_1")


    tf.keras.backend.clear_session()
    return score[1]
#DNN_numpy = np.zeros((len(eta_vals), len(lam_vals)), dtype=object)


neuralNetwork(lam, eta, deca)

#for i, lam in enumerate(lam_vals):
#    for j, eta in enumerate(eta_vals):
#        dnn = neuralNetwork(lam, eta, deca)
#        print("Learning rate  = ", eta)
#        print("lambda = ", lam)
#        print("Accuracy score on test set: ", dnn)


