#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 12:47:08 2019

@author: houjie
"""


import numpy as np
import pandas as pd
import tensorflow as tf

tf.keras.backend.clear_session()
fil_diff = pd.read_excel('46_Li_Astro_1520_relative_d10_test_elec1.xlsx', skiprows = 0)
fil_proli = pd.read_excel('46-Li_NPM_2047_relative_d10_test_elec2.xlsx', skiprows = 0)

data_diff= np.asarray(fil_diff)
data_proli = np.asarray(fil_proli)


def remove_large_values(array):
    """
    Removes first column (frequency), and removez
    sequences with too large values (unphysical).
    """
    dummy_arr = []
    for i in range(1, len(array[:, 0])):
        too_large = False
        for j in range(0,len(array[0, :])):
            if array[i, j] > 300:
                too_large = True
        if not too_large:
            dummy_arr.append(array[i, :]/max(array[i, :]))
    return np.asarray(dummy_arr)

def add_dimension(arr):
    new_arr = []
    for i in range(len(arr[0,:])):
        new_arr.append([ arr[:,i] ])
    return np.asarray(new_arr)


def pick_frequency_interval(arr,step):
    new_arr = []
    for i in range(step,len(arr[0,:]),step):
        new_arr.append(arr[i,:])
    return np.asarray(new_arr)

data_diff = remove_large_values(data_diff)
data_proli = remove_large_values(data_proli)

data_diff = np.rot90(data_diff)
data_proli = np.rot90(data_proli)

data_diff = np.flip(data_diff,axis = 0)
data_proli = np.flip(data_proli,axis = 0)
svar = np.ones(len(data_diff[0,:]))
svar_proli = np.zeros(len(data_proli[0,:]))

data_diff_svar = np.vstack((data_diff, svar))
data_proli_svar = np.vstack((data_proli, svar_proli))

total_data = np.concatenate((data_diff_svar, data_proli_svar), axis =1)
total_data = add_dimension(total_data)
total_data = np.swapaxes(total_data,1,2)
np.random.shuffle(total_data)

test_data = total_data[:,:-1]
test_answers = total_data[:,-1].astype(dtype=int)
from tensorflow.keras.utils import to_categorical
test_answers = to_categorical(test_answers)

model_1 = tf.keras.models.load_model("day_20_46")
model_1.summary()
score = model_1.evaluate(test_data, test_answers, verbose=1)
print('Test loss:', score[0])
print('Test accuracy:', score[1])
